# 🚀 Project Clustering App

A simple **Streamlit web app** that clusters project ideas based on textual similarity using **TF-IDF** and **KMeans**.

## 🧠 Features
- Enter multiple project descriptions (one per line)
- Automatically clusters similar projects
- Simple, interactive UI

## ⚙️ How to Run Locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open: [http://localhost:8501](http://localhost:8501)

## 🌍 Deploy on Streamlit Cloud
1. Push this folder to a **GitHub repository**.
2. Go to [https://share.streamlit.io](https://share.streamlit.io)
3. Connect your repo, select `app.py`, and click **Deploy**.

You’ll get a free public link like  
👉 `https://yourname-projectcluster.streamlit.app`
