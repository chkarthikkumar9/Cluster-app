import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

st.set_page_config(page_title="Project Clustering App", page_icon="🚀")

st.title("🚀 Project Clustering App")
st.write("Cluster similar projects automatically using AI & NLP")

# --- Input section ---
st.markdown("### 🧾 Enter your project descriptions (one per line):")
default_text = """Rapido is a ride-sharing app for bike transportation
Uber is a car-based ride-hailing and transportation service
Naukri is an online job portal for employment opportunities"""
projects_input = st.text_area("Projects:", default_text, height=200)

# --- Cluster count selector ---
n_clusters = st.slider("Select number of clusters", 2, 5, 2)

# --- Button ---
if st.button("🔍 Cluster Projects"):
    projects = [p.strip() for p in projects_input.split("\n") if p.strip()]
    if len(projects) < n_clusters:
        st.error("⚠️ Please enter more projects than the number of clusters.")
    else:
        df = pd.DataFrame({'Project_Description': projects})

        # Convert text to TF-IDF vectors
        vectorizer = TfidfVectorizer(stop_words='english')
        X = vectorizer.fit_transform(df['Project_Description'])

        # Apply KMeans clustering
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        df['Cluster'] = kmeans.fit_predict(X)

        # --- Display results ---
        st.markdown("## 📊 Clustering Results")
        for cluster in sorted(df['Cluster'].unique()):
            st.markdown(f"### 🔹 Cluster {cluster}")
            for project in df[df['Cluster'] == cluster]['Project_Description']:
                st.write(f"- {project}")

        # --- Optional visualization ---
        st.bar_chart(df['Cluster'].value_counts().sort_index())
